package com.gaurav.foodapp.restfulservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
